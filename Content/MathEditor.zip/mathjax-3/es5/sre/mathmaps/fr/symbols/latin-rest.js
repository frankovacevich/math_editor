[{"locale":"fr"},{"key":"24C8","mappings":{"default":{"default":"S majuscule cerclée"}},"category":"So"}]
